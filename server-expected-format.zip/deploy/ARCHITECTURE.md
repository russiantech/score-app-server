# System Architecture Diagram

## How It All Works Together

┌─────────────────────────────────────────────────────────────────────────┐
│                           SERVER BOOT SEQUENCE                           │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
                          ┌──────────────────┐
                          │  Server Reboots  │
                          └──────────────────┘
                                    │
                                    ▼
                          ┌──────────────────┐
                          │   Wait 30 sec    │
                          └──────────────────┘
                                    │
                                    ▼
                    ┌───────────────────────────┐
                    │   @reboot Cron Job        │
                    │   Triggers Automatically  │
                    └───────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         SUPERVISOR STARTS                                │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    │   Supervisor Daemon           │
                    │   ~/supervisor/supervisord    │
                    │   (Always Running)            │
                    └───────────────┬───────────────┘
                                    │
                                    ▼
                    ┌───────────────────────────┐
                    │   Reads Configuration     │
                    │   supervisord.conf        │
                    └───────────────────────────┘
                                    │
                                    ▼
                    ┌───────────────────────────┐
                    │   Starts Your FastAPI     │
                    │   App (uvicorn)           │
                    └───────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        NORMAL OPERATION                                  │
└─────────────────────────────────────────────────────────────────────────┘

┌──────────────┐          ┌──────────────┐          ┌──────────────┐
│  Incoming    │          │  Supervisor  │          │   FastAPI    │
│  Requests    │───────▶  │   Monitors   │──────▶   │     App      │
│              │          │              │          │  (uvicorn)   │
└──────────────┘          └──────────────┘          └──────────────┘
                                 │                          │
                                 │                          ▼
                                 │                  ┌──────────────┐
                                 │                  │ Processes    │
                                 │                  │ Requests     │
                                 │                  └──────────────┘
                                 │                          │
                                 │                          ▼
                                 │                  ┌──────────────┐
                                 │                  │ Returns      │
                                 │                  │ Responses    │
                                 │                  └──────────────┘
                                 │
                                 ▼
                         ┌───────────────┐
                         │   Logs        │
                         │   Everything  │
                         └───────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                        CRASH RECOVERY                                    │
└─────────────────────────────────────────────────────────────────────────┘

                    ┌───────────────────────┐
                    │   App Crashes!        │
                    │   (Exception/Error)   │
                    └───────────────────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │   Supervisor Detects  │
                    │   Process Died        │
                    │   (~1 second)         │
                    └───────────────────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │   Waits 1 second      │
                    └───────────────────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │   Restarts App        │
                    │   Automatically       │
                    └───────────────────────┘
                                │
                                ▼
                    ┌───────────────────────┐
                    │   App Running Again   │
                    │   ✓ Back Online       │
                    └───────────────────────┘

          (Will retry 999,999 times until successful)

┌─────────────────────────────────────────────────────────────────────────┐
│                      DIRECTORY STRUCTURE                                 │
└─────────────────────────────────────────────────────────────────────────┘

/home/YOUR_USER/
│
├── supervisor/                          ← Supervisor installation
│   ├── supervisord.conf                ← Main config
│   ├── supervisord.pid                 ← Process ID
│   ├── supervisor.sock                 ← Unix socket
│   │
│   ├── conf.d/                         ← App configurations
│   │   └── your-app.conf              ← Your FastAPI app config
│   │
│   └── logs/                           ← Supervisor logs
│       ├── supervisord.log            ← Daemon logs
│       └── monitor.log                ← Monitor script logs
│
├── virtualenv/YOUR_DOMAIN/3.X/         ← Python environment
│   └── bin/
│       ├── activate                    ← Virtualenv activator
│       ├── python                      ← Python interpreter
│       ├── pip                         ← Package installer
│       ├── uvicorn                     ← ASGI server
│       ├── supervisord                 ← Supervisor daemon
│       └── supervisorctl               ← Supervisor controller
│
└── YOUR_APP_DIR/                        ← Your application
    ├── main.py                         ← FastAPI app
    ├── requirements.txt                ← Dependencies
    ├── .env                            ← Secrets (you create)
    ├── .gitignore                      ← Git ignore file
    │
    ├── control.sh                      ⭐ Management script
    ├── monitor.sh                      🔍 Health monitor
    ├── DEPLOYMENT_README.md            📖 Documentation
    │
    └── logs/                           ← Application logs
        └── app.log                     ← Your app output

┌─────────────────────────────────────────────────────────────────────────┐
│                      MANAGEMENT WORKFLOW                                 │
└─────────────────────────────────────────────────────────────────────────┘

                         You Type Command
                                │
                                ▼
               ┌────────────────────────────────┐
               │    bash control.sh [command]   │
               └────────────────────────────────┘
                                │
                ┌───────────────┴────────────────┐
                │                                │
                ▼                                ▼
      ┌──────────────────┐           ┌──────────────────┐
      │  Simple Commands │           │  Complex         │
      │  (status, logs)  │           │  Commands        │
      └──────────────────┘           │  (start, stop)   │
                │                     └──────────────────┘
                │                                │
                ▼                                ▼
      ┌──────────────────┐           ┌──────────────────┐
      │  Direct Action   │           │  Call            │
      │  (show output)   │           │  supervisorctl   │
      └──────────────────┘           └──────────────────┘
                                                 │
                                                 ▼
                                     ┌──────────────────┐
                                     │  Supervisor      │
                                     │  Executes        │
                                     └──────────────────┘
                                                 │
                                                 ▼
                                     ┌──────────────────┐
                                     │  App Responds    │
                                     └──────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                      MONITORING & LOGGING                                │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  FastAPI    │────▶│  Supervisor │────▶│   Log       │────▶│   You       │
│  App        │     │  Captures   │     │   Files     │     │   View      │
│  stdout/err │     │  Output     │     │   Rotate    │     │   Logs      │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
      │
      │ Writes to
      ▼
┌─────────────┐
│  app.log    │     Max 50MB per file
│  (rotated)  │     Keeps 10 backups
└─────────────┘     = 500MB total history

Optional Monitor (every 5 min via cron):
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Cron Job   │────▶│  monitor.sh │────▶│  Checks:    │
│  */5 * * *  │     │  Runs       │     │  - Process  │
└─────────────┘     └─────────────┘     │  - Health   │
                                         │  - Restart  │
                                         └─────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                      TRAFFIC FLOW                                        │
└─────────────────────────────────────────────────────────────────────────┘

Internet
   │
   ▼
┌──────────────┐
│   Apache/    │  ← Usually configured in cPanel
│   Nginx      │
│   Reverse    │
│   Proxy      │
└──────────────┘
   │
   │ Forwards to
   │
   ▼
┌──────────────┐
│ localhost:   │
│   8001       │  ← Your FastAPI app port
└──────────────┘
   │
   ▼
┌──────────────┐
│   Uvicorn    │  ← ASGI server
│   Workers    │
└──────────────┘
   │
   ▼
┌──────────────┐
│   FastAPI    │  ← Your application
│   Routes     │
└──────────────┘
   │
   ▼
┌──────────────┐
│   Business   │  ← Your code
│   Logic      │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                   WHAT HAPPENS WHEN...                                   │
└─────────────────────────────────────────────────────────────────────────┘

Scenario: You disconnect SSH
├─ Supervisor: Still running (daemon)
├─ FastAPI App: Still running (supervised)
└─ Result: ✓ Everything continues normally

Scenario: App crashes
├─ Supervisor: Detects exit (~1 second)
├─ Action: Waits 1 second, restarts app
├─ Retries: Up to 999,999 times
└─ Result: ✓ App back online in ~2 seconds

Scenario: Server reboots
├─ Cron: Triggers @reboot after 30 seconds
├─ Supervisor: Starts via cron job
├─ FastAPI: Auto-started by supervisor
└─ Result: ✓ App running in ~1 minute

Scenario: Out of memory (killed by cPanel)
├─ Supervisor: Detects process killed
├─ Action: Restarts immediately
├─ Note: If repeatedly killed, check memory usage
└─ Result: ✓ Restarts when resources available

Scenario: You run 'bash control.sh restart'
├─ Control script: Calls supervisorctl restart
├─ Supervisor: Gracefully stops app (10 sec timeout)
├─ Supervisor: Starts fresh app instance
└─ Result: ✓ Clean restart, new code loaded

┌─────────────────────────────────────────────────────────────────────────┐
│                      SECURITY MODEL                                      │
└─────────────────────────────────────────────────────────────────────────┘

Everything runs as YOUR user (not root)
   │
   ├─ Supervisor daemon: your_user
   ├─ FastAPI app: your_user
   └─ All files owned: your_user

Permissions:
   ├─ supervisord.conf: 600 (only you read/write)
   ├─ .env file: 600 (only you read/write)
   ├─ supervisor.sock: 700 (only you access)
   ├─ control.sh: 755 (you execute, others read)
   └─ logs: 644 (you write, others read if needed)

Network:
   ├─ App listens: localhost:PORT only
   ├─ Not exposed: to internet directly
   └─ Accessible via: reverse proxy (cPanel)

Secrets:
   ├─ Stored in: .env file
   ├─ Never in: git repository
   ├─ Loaded by: app at runtime
   └─ Not visible: in process list

┌─────────────────────────────────────────────────────────────────────────┐
│                   COMPARISON TO ALTERNATIVES                             │
└─────────────────────────────────────────────────────────────────────────┘

┌────────────┬────────────┬────────────┬────────────┬────────────┐
│            │   nohup    │    cron    │ Supervisor │  systemd   │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Crash      │     ❌     │     ✅     │     ✅     │     ✅     │
│ Recovery   │            │  2-5 min   │  ~1 sec    │  instant   │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Memory     │     ❌     │     ✅     │     ✅     │     ✅     │
│ Kill       │            │  2-5 min   │  ~1 sec    │  instant   │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Reboot     │     ❌     │     ✅     │     ✅     │     ✅     │
│ Survival   │            │  (cron)    │  (cron)    │  native    │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Resource   │    None    │   Wastes   │  ~2MB RAM  │  ~1MB RAM  │
│ Usage      │            │   polls    │            │            │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Management │   Manual   │   Manual   │    Easy    │    Best    │
│            │            │            │  commands  │  commands  │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Logging    │   Manual   │   Manual   │  Built-in  │  journald  │
│            │            │            │  rotation  │            │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Requires   │    None    │    None    │    None    │    ROOT    │
│            │            │            │            │   ⚠️ ⚠️    │
├────────────┼────────────┼────────────┼────────────┼────────────┤
│ Best for   │   Quick    │  Fallback  │  cPanel    │   VPS/     │
│            │   tests    │            │  hosting   │  Dedicated │
└────────────┴────────────┴────────────┴────────────┴────────────┘

         This deployment = Supervisor (Perfect for cPanel!)
```

*Legend:*
- ✅ = Works perfectly
- ❌ = Doesn't protect
- 🔍 = Optional monitoring
- ⭐ = Primary tool
- ⚠️ = Requires special access
