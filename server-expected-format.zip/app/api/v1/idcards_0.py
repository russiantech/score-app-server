# app/api/v1/id_cards.py
"""
Student ID Card generation endpoints - Complete implementation
"""

from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
from uuid import UUID
import base64
from io import BytesIO
from PIL import Image

from app.database import get_db
from app.models.user import User
from app.models.enrollment import Enrollment
from app.api.deps import get_current_user
from app.utils.responses import api_response

router = APIRouter()


@router.get("/students/{student_id}/data")
async def get_id_card_data(
    student_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get student data for ID card generation.
    Students can only access their own data.
    """
    # Authorization check
    if not (
        current_user.is_admin or 
        current_user.is_tutor or 
        str(current_user.id) == str(student_id)
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to access this student's data"
        )
    
    try:
        # Get student
        student = db.query(User).filter(User.id == student_id).first()
        if not student:
            raise HTTPException(404, "Student not found")
        
        # Check if user has student role
        if not student.has_role('student'):
            raise HTTPException(403, "User is not a student")
        
        # Get enrollments with course details
        enrollments = db.query(Enrollment).filter(
            Enrollment.student_id == student_id
        ).all()
        
        courses = []
        for enrollment in enrollments:
            course = enrollment.course
            courses.append({
                "id": str(course.id),
                "title": course.title,
                "code": course.code,
                "enrolled_date": enrollment.created_at.isoformat() if enrollment.created_at else None
            })
        
        return {
            "student": {
                "id": str(student.id),
                "names": student.names if student.names else student.username,
                "email": student.email,
                "student_id": student.username if student.username else str(student.id)[:8].upper(),
                "phone": student.phone if hasattr(student, 'phone') else None,
                "date_of_birth": student.date_of_birth if hasattr(student, 'date_of_birth') else None,
                "profile_picture": student.avatar_url if hasattr(student, 'avatar_url') else None
            },
            "courses": courses
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error in get_id_card_data: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching ID card data: {str(e)}"
        )


@router.post("/students/{student_id}/upload-photo")
async def upload_id_photo(
    student_id: UUID,
    photo: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Upload/update student photo for ID card.
    Processes image, resizes it, and returns base64 encoded data.
    """
    # Authorization check
    if str(current_user.id) != str(student_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only upload your own photo"
        )
    
    try:
        # Validate file type
        if not photo.content_type or not photo.content_type.startswith('image/'):
            raise HTTPException(400, "File must be an image")
        
        # Read file contents
        contents = await photo.read()
        
        # Validate file size (max 2MB)
        if len(contents) > 2 * 1024 * 1024:
            raise HTTPException(400, "Photo must be less than 2MB")
        
        # Process image
        image = Image.open(BytesIO(contents))
        
        # Resize to standard size (passport photo dimensions)
        max_size = (600, 600)
        image.thumbnail(max_size, Image.Resampling.LANCZOS)
        
        # Convert to RGB if necessary
        if image.mode in ('RGBA', 'P'):
            image = image.convert('RGB')
        
        # Save to BytesIO
        output = BytesIO()
        image.save(output, format='JPEG', quality=85, optimize=True)
        output.seek(0)
        
        # Convert to base64
        photo_base64 = base64.b64encode(output.read()).decode('utf-8')
        photo_data = f"data:image/jpeg;base64,{photo_base64}"
        
        # Optionally update student record
        # student = db.query(User).filter(User.id == student_id).first()
        # if student and hasattr(student, 'avatar_url'):
        #     student.avatar_url = photo_data
        #     db.commit()
        
        return {
            "success": True,
            "photo_url": photo_data,
            "message": "Photo uploaded successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error uploading photo: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error uploading photo: {str(e)}"
        )


@router.get("/students/{student_id}/generate-pdf")
async def generate_id_card_pdf(
    student_id: UUID,
    course_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Generate ID card data for PDF export (optional feature).
    Frontend handles rendering via html2canvas.
    """
    # Authorization check
    if str(current_user.id) != str(student_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only generate your own ID card"
        )
    
    try:
        # Get student
        student = db.query(User).filter(User.id == student_id).first()
        if not student:
            raise HTTPException(404, "Student not found")
        
        # Get enrollment
        enrollment = db.query(Enrollment).filter(
            Enrollment.student_id == student_id,
            Enrollment.course_id == course_id
        ).first()
        
        if not enrollment:
            raise HTTPException(404, "Enrollment not found")
        
        course = enrollment.course
        
        return {
            "student_name": student.names if student.names else student.username,
            "student_id": student.username if student.username else str(student.id)[:8].upper(),
            "email": student.email,
            "course_name": course.title,
            "course_code": course.code,
            "enrolled_date": enrollment.created_at.isoformat() if enrollment.created_at else None,
            "phone": student.phone if hasattr(student, 'phone') else None
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error generating ID card: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating ID card: {str(e)}"
        )


@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "ok",
        "service": "id_cards",
        "message": "ID Card service is running"
    }